# A vector containing a sequence of odd numbers from 1 to 100
a<-seq(1,100,2)
Num_vect<-c(a)
print(Num_vect)
print(a)

#Creating a numeric vector
b<-c(1,2,3,4,5,8,6,2,11)

#creating a 3*3 matrix
matrix(b, nrow=3, ncol=3)
matrix1<-matrix(a,nrow=25,ncol=2,byrow=T)
matrix1
matrix2<-matrix(a,nrow=2,ncol=25)
matrix2
#REmoving NA from a vector
c<-c(NA,11:15,NA,NA)
typeof(c)
c
ifelse(is.na(c),0,a)

#Replace the first occurrence of a with ‘$’
x=c("apple","banana","grape")
x
sub("a","$",x)

write.csv(data1,"test_write.csv")
