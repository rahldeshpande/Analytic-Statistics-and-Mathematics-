x<-1:100
x
y=x*x
y
plot(x,y)
z=x*x*x
plot(x,z)


x+a=101
