#Arrays

#Array
a <- array(1:24, dim = c(4, 3, 2))
a
a[1, 3, 2]
  
arr <-1:20 
is.matrix(arr) 
dim(arr)

dim(arr)<-c(5,4)
is.matrix(arr)
is.table(arr) 

w = array(1:18,dim=c(3,3,2))

A <- letters[1:16]
A
dim(A)<-c(2,2,4)
A

A[,,1:2]

A[,,3] 

#Lists 
x <-list(u=2, v="abc") 
x
x$u

j <-list(name="hue", sal=6000, union=F)
j$sal
j[["sal"]] 
j[[2]]

#Adding & Deleting List Elements
z <-list(a="jklm",b=200) 
z
z$a
z$b

#Adding to List
z$c <-" r -project" # add a c component project 
z
z$a
z$b
z$c

#delete a list component by setting it to NULL
z$b <-NULL
z

#Using the lapply() and sapply() Functions 
list(3:9,22:24)
median(3:9)
median(22:24)
lapply(list(3:9,22:24),median)

sapply(list(2:4,45:49),median)

# Recursive Lists 
c(list(a=3,b=4,c=list(d=6,e=8))) 
c(list(a=1,b=2,c=list(d=5,e=9)),recursive=T) 

b <- list(u = 5, v = 12)
c <- list(w = 13)
a <- list(b,c)
a

#Creating a Data Frame
kids <-c("Sam", "Nick", "Rits") 
ages <-c(11,10,8) 


d <-data.frame(kids,ages,stringsAsFactors=FALSE) 
d
class(d)
attach(d)
kids
#Accessing Data Frames
d[[1]] 
d$kids
d[,1]
d[1,]
str(d)
names(d)
class(d)
head(d)
head(d,2)
tail(d,2)

#Subset Of Data Frames
d[2:3,]
d[2:3,2]
class(d[2:3,2])
d[d$ages >= 10,]

#rbind() and cbind() Functions
rbind(d,list("Lara",15)) 

a <- c(1,2,3,4)
b <- c(5,6,7,8)
c <-rbind(a,b)
c
c <-cbind(a,b)
c

#Factors
x <-c('Y', 'N', 'N')
xfac <-factor(x)
xfac
str(xfac)

numbers <- c(24,28,45,36,34,26) 
subject <- c("maths","english","english","maths","english","maths") 
tapply(numbers,subject,mean)

d <-"C: /Users/Yogesh/Desktop/unsupervised.pdf"

#exe <- "C:/Prpgram Files/xpdfbin-win-3.04/bin64/pdftotext.exe"
#system(paste("\"", exe, "\" \"", d, "\"", sep = "")


exe <- system(paste('"C:/Program Files/xpdfbin-win-3.04/bin64/pdftotext.exe"', 'd'), wait=FALSE)

txtfile <-sub(".pdf", ".txt", d) 
txtfile

#Creating new Variables
mydata <- data.frame(u = c(4, 8, 6, 4), v=c(9, 27, 7, 8), z =c(1, 7,17, 3)) 

mydata$sumx < -mydata$u + mydata$v  + mydata$z

mydata$meanx <- (mydata$u + mydata$v  + mydata$z)/3



