#Matrix

#T(Matrix_name) transpose of a matrix function.
