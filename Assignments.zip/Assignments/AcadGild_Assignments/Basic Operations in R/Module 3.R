#To check R version 
R.Version()
R.version.string
#to check library path
.libPaths()
#to check all libraries
library()
#to check frequently used packages.
search()
#basic functions
9+7; 2*4; 15-12
log(10)
exp(1)

#Rounding
floor(5.9) #rounding down
ceiling (2.9) #rounding up

#Creating A Vector
a<-1.3
class(a)
a <- 5:10
a
length(a)

# Assigning Values to vectors

b <- c(1, 2, 3, 4)

A<-1:6
A
B<-c(6,7)
B
C <- A*B
C

#Types of Vector
#Numeric vector
a <- c(4,3,6.3,6,-8,9)
typeof(a)
class(a)

#Character vector
b <- c("nine","two","eight")
b
typeof(b)
class(b)

c <- c(TRUE,TRUE,TRUE,FALSE,TRUE,FALSE)
typeof(c)

a[c(1,3)]#first and 3rd element of a

#Missing values
a<-c(NA,11:15,NA,NA)
a
mean(a)
#need to remove NA, hence na.rmc command
mean (a,na.rm=T)

a<-c(11:15,NA,NA,12:20)
a

# To check for the location of missing values within a vector
a<-c(11:15,NA,NA,12:20)
a

which(is.na(a))# 6th and 7th vector ois NA

#To convert the NA to 0, use the ifelse function :
  ifelse(is.na(a),0,a)
  
y<-0:7
y

sum(y)

sum(y<3)

sum(y[y<5])

y<3

a<-c(2,9,9,9,2)
sort(a)
sum(sort(a)[2:3])

a<-0:6
a
a<4
a
all(a>0)
all(a>-1)
any(a<0)
sum(a<2)
sum(a<10)

seq(1:10)

seq(2,10)
seq(20,10)

seq(0,5,0.5)
seq(5,0,-.5)

x <- rep(6,4)
x

#Generating Repeated Sequence
rep(c(11,12,13),3)
rep(1:2,3)
rep(c(11,12,13),each=2)

#Sorting, Ranking & Ordering
sales<-c(100,50,75,150,200,25)
rank<-rank(sales)
sorted<-sort(sales)
ordered<-order(sales)
view <- data.frame(sales,rank,sorted,ordered)
view
#Filtering Vectors
x <- c(6,1:3,NA,12)
x
x[x > 5]

#Subset function handles NA
subset(x,x > 5)

#The Selection Function which()
z <- c(6,5,-3,7)
which(z*z > 9)
z*z > 9

#To know the values
B <- z[z*z > 9]
B

#ifelse() function
x <- 1:10
y <- ifelse(x %% 3 == 0, " Y ", " N ") # %% is the mod operator
y

#Nested ifelse()
h = c("M","F","F","I","M","M","F")
ifelse(h == "M",1,ifelse(h == "F",2,3))

#Character Strings
a<-"hello"
b<-"55"
c(a,b)
c

as.numeric(a)
as.numeric(b)

sports<-
  c("badminton","tabletennis","cricket","basketball")

length(sports)
nchar(sports)
class(sports)
is.factor(sports)

popularsports<-
  c("rugby","cricket","badminton","football","baseball","tennis","basketball")

which(sports %in% popularsports)
sports [which(sports %in% popularsports)]

paste(a,b,sep="")
paste(a,b)
paste(a,b,"a longer phrase containing blanks",sep="")

d<-c(a,b,"new")
d
e<-paste(d,"a longer phrase containing blanks")
e

letters
LETTERS

which(letters=="k")
noquote(letters)
noquote(LETTERS)

#Using grep Function (Pattern matching)
X = c("apple","potato","grape","10","blue.flower")
grep("a",X)

grep("a",X,value=F)
grep("a",X,value=TRUE)
grep("[[:digit:]]",X,value=TRUE)

#Using substr
word <- "apples"
substr(word,start=2,stop=5)

substr(word,start=1,stop=1) <- "ban"
word

substr(word,start=1,stop=3) <- "ban"
word

#Using chartr
word <- "Apples"
chartr(old="A",new="a",word)
chartr(old="Ae",new="aE",word)

#Using strsplit
word="apple|lime|orange"
word
v=strsplit(word,split="|",fixed=TRUE)
v
v=strsplit(word,split="|")
v

#Using sub and gsub
x=c("apple","banana","grape")
sub("a","$",x)

y <- c("apple","banana","grape")
grep("a",y)
grep("a",y,value=TRUE)

gsub("a","$",x)

#Using regexpr, gregexpr & regmatches
z <- c("apple","banana","grape")
r=regexpr("a",z)
r

gregexpr("ss","Assessed")

regmatches(z,r)

#Using sprintf
i <- 2
s <- sprintf("the cube of %d is %d",i,i^3)
s


y <- matrix(c(1,2,3,4),nrow=2,ncol=2)
y

M<-matrix(c(2,3,8,1,1,5,7,9,1),nrow=3)
M
class(M)
attributes(M)

Minv = t(M)
Minv

X<-matrix(c(20,10,80,50,60,100,90,30,40,70,50,60),nrow=3)
X

rownames(X)<-rownames(X
                      ,do.NULL=FALSE,prefix="Test.")
X

subs<-c("Maths", "English", "Science", "History")
colnames(X)<-subs
X

#Calculations On Rows Or Columns Of The Matrix
X<-matrix(c(50,60,40,90,100, 80,50, 90,10, 80,30, 70),nrow=3)
mean(X[,4])
sd(X[3,])
rowSums(X)
colSums(X)
rowMeans(X)
colMeans(X)

#Adding Rows And Columns To The Matrix

X<-rbind(X,apply(X,2,mean))
X<-cbind(X,apply(X,1,var))
X

colnames(X)<-c(1:4,"variance")
rownames(X)<-c(1:3,"mean")
X

#Evaluating Functions With Apply
X<-matrix(1:16,nrow=4)
X
apply(X,1,sum)
apply(X,2,sum)
apply(M, 1, min)
apply(M, 2, max)
apply(X,1,sqrt)
apply(X,1,function(x) x^2+x)

#Sweep
matdata<- matrix(c(50,60,40,90,100, 80,50, 90,10, 80,30, 70),nrow=4)
matdata
cols<-apply(matdata,2,mean)
cols
sweep(matdata,2,cols)

