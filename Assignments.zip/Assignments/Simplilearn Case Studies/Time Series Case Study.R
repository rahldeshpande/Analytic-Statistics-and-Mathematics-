getwd()
catd<-read.csv("Final-CatData.csv",header=T)
head(catd)
#numbers are the quantity sold of each type
#weekly data with a unique date for a week
barcd<-read.csv("Final-Broccoli.csv",header=T)
head(barcd)
#aattach both the datasets
attach(catd)
attach(barcd)

#*catagory dataset analysis* 
#now check the complete dataset
catd
#there are total 66 rows-> data for 66 weeks.
#understand the data and start work over
#lets draw a scattered plot for this data set
#to limit y axis, use the function ylim, for that define yrange
yrange<-range(c(Kitchen,Grains,Vegetables,Merchandise,Pulses)) #y axis limit is set

split.screen(c(1,1))
close.screen(all=T)
plot(Week.of.TDATE,ylim=yrange,Kitchen)#printed kitchen quantity
#add scattered plot for all the catagories uning point function
points(Week.of.TDATE,col='RED',Pulses)#fluctuating , just like kitchen
points(Week.of.TDATE,col='GREEN',Grains)#almost constant trend, some hikes can be seen for a specific period
points(Week.of.TDATE,col='MAGENTA',Merchandise)# no specific pattern is observed, too much inconsistency, highest standard deviation->too much fluctuation
points(Week.of.TDATE,col='BLUE',Vegetables)#almost constant , some fluctuations
#highest saling are grains, lowest saling are kitchen and pulses. low pulses, low proteins in these people.
#vegetables, average saling

#summerize the data
summary(catd)
plot(catd)
boxplot(catd)
#check skewness and kurtosis, standard deviation (boxplot)
#standard deviation for pulses is the smalles, it's demand  is uniform throughout the year
#standard deviation for merchandise is the highest, no pattern/trend
#grain pulses and vegetables are negatively skewed
#kitchen and merchandise are positively skewed

#Descriptive analysis is done. Let's do Diagnostic analysis
#let'c check if there is any relation between dependent and independent varibles or independent variables. Hence, use corelation (Co-relation, chi squared test etc, analysis of variance)
#check for corelation between all sales data

#why corelation not ci squared test? Answer- values here are continuous, numeric and non-catgorical.
#create a chart for Descriptive analysis and its types, diagnostic analysis and its types, time seriese etc and put it all over.

#corelation can be performed on only numeric data, we need to remove week column from the dataset.
dim(catd)
attributes(catd)
class(catd)
catdnum<-catd[,-1] #removed first variable
class(catdnum)
#now run corelation
cor(catdnum)
#grains and vegetables, vegetables and pulses have higher positive corelation
#no negative corelation is ibserved
#all the demands are positively corelated to each other, none has negativeeffect on other.
#if we develope a model to predict the sales for grains, it will work well for vegetables and pulses . Effect will depend on their correlation.

#*Analyze Broccoli dataset*

head(barcd)
#it has 5 variables and 69 objects.
#yearwk is a unique identifier for every week.
#rainfall is the value in centimeter for the perticular city in week.
table(barcd$SEASON)
#season is a descrete variable.
#season 1 for winter and 0 for others. winmter is assumed form November to February
#average is the rate of broccoli across the market
barcd$SEASON<-as.numeric(barcd$SEASON)
summary(barcd)

#descriptive analysis
summary(barcd)
#rate of the broccoli remains almost constant , ranging from 77 to 96. 
#rainfall: maean is 2.32 i.e. rainfall was very low throught the year except some period where it was 22.24

#diagnostic analysis
cor(barcd)
#rate is negatively correlated with quantity sold.
#week, rainfall and season ahave almost no effect on quantity. if they have, then week and season has a negative correlation while rainfall has a positive corelation. 
#we can use pairs functions as well.
pairs(barcd)
#it'll give a graph for all.
cov(barcd)


#Predictive Analysis
#create a seperate dataset for vegtable from base dataset
veg_catd<-catd[,5]
veg_catd
summary(veg_catd)
#considering quartile and mean value, min value i.e. 15660 seams like a outlier. Let's remove that to get a better predictions.
veg_catd = veg_catd[which(veg_catd>15660)]
veg_catd
summary(veg_catd)
#no change in the summary, why?

#let's define a time seriese

Ts_veg_catd<-ts(data=veg_catd,start = 1,frequency = 52)
head(Ts_veg_catd)
Ts_veg_catd

#let's try HoldWinters method
fit_hw<-HoltWinters(Ts_veg_catd)
#we need to take away season factor, i.e. gamma
fit_hw<-HoltWinters(Ts_veg_catd,gamma = F)
plot(fit_hw)
#fit seems fine, we need to check mathematical accuracy later.

#lte's try simple moving average for this dataset
plot(Ts_veg_catd)
fir_MA<- ma(Ts_veg_catd,order = 3)

lines(fir_MA,col="GREEN")
#lines function is used to plot the lines on the graph already created


fit_MA_six<-ma(Ts_veg_catd,order=6)
lines(fit_MA_six,col="BLUE")
#crests and troughs are flattened for 6 week's moving average. 3 week's moving average looks better.
library(forecast)
?ma

#now we'll do linear regression model to see the seasonality and trend changes. 

fit_lm<-tslm(Ts_veg_catd ~ trend + season)

#we'll use the accuracy finction to calculate errors in all fits.
accuracy(fit_lm$fitted.values,Ts_veg_catd)
accuracy(fit_hw$fitted,Ts_veg_catd)
accuracy(fit_MA_six,Ts_veg_catd)
accuracy(fir_MA,Ts_veg_catd)


#                    ME     RMSE      MAE       MPE     MAPE       ACF1 Theil's U
#Test set -4.411555e-13 4692.144 1735.359 -1.645904 4.253367 0.02167448 0.5979594
#ME- Mean Error, Mean Absolute Error, Mean Percentage Error, Mean Average Percentage Error
#Root_mean_square_error




#Observations-
#LM seems the best fit


Predict_lm<-forecast(fit_lm,h=20)
plot(Predict_lm)

Predict_hw<-forecast(fit_hw, h=20)
plot(Predict_hw)


#Broccoli dataset analysis

# we'll do multiple linear regression analysis

attach(barcd)

head(barcd)

fit1<-lm(QTY  ~ AVGRATE+YEARWK+RAINFALL+SEASON)
summary(fit1)
# P values for average is significant, but for season and rainfall it is way higher than the significant level i.e. 0.05 . Hence, practically, they do not have any effect on demand of quantity of Broccoli.
#average rate is negatively efecting the quantity of broccoli.  (Negatively corelated)



#let's check if there is any interaction between season and rainfall and wether it ihas any effect on qty

fit2<-lm(QTY ~ AVGRATE+YEARWK+RAINFALL*SEASON)
summary(fit2)

#adjusted r square reduces.


fit3<-lm(QTY ~ AVGRATE+YEARWK)
summary(fit3)
