Branddata<-read.csv("BrandData.csv",header=T)
View(Branddata)
summary(Branddata)
head(Branddata)
attach(Branddata)
search()

Time_Series<-ts(Branddata$NetSales_Qty , start = c(2010,4) , frequency = 12)

plot(Time_Series)

#iusing forecast package and it's funcions
library(forecast)

Time_Arima<-auto.arima(Time_Series)

#moving average and seasonal values
#AIC Values to compare other models.

Time_Arima

#checking confidence interval values

confint(Time_Arima)

#lets forecast usoing forecast function - forecaste function takes no of values to be forecastes as an inout

forecast(Time_Arima,20)
# it has forecaseed data till November 2015
#shows 80% and 95% confidence intervals, high and low both

plot(forecast(Time_Arima))

#dark grey area in graph represents 80% forecasted numbers while light gray shows 95% forecastes interval.
#--------So far we have used automatic auto regrssive termss------

#using Arima method only

#order of  diffferentiations and moving average terms
#most commomnly used Arima values are c(0,1,1)

Time_Arima_m<-arima(Time_Series, order = c(0,1,1) ,seasonal = list(order =c(0,1,1)))

forecast(Time_Arima_m,20)
plot(forecast(Time_Arima_m,20)) #more smoother than the earlier auto arima model

## let's do smoothing now

rime_ets<-ets(Time_Series)
rime_ets
# ETS(M,A,M) -> multilicative error, additive trend, multiplicative seasonality model

forecast(rime_ets,20)
#trend decreases or remains almost constant.
plot(forecast(rime_ets))


#Holt'swinter model - contains seasonality as well.

time_hw<-HoltWinters(Time_Series)
time_hw
forecast(time_hw,20)
plot(forecast(time_hw,20))


#lets do linear regression model
#forecasting time series models, but linear regression is cause and effect model.

time_tslm<-tslm(Time_Series~trend+season)
time_tslm #similar to linear regression model
#12 months, 12 sessions
forecast(time_tslm,h=20)
plot(forecast(time_tslm,h=20))
#no continuity in the plot. 


#see all grphs together

split.screen(figs=c(2,2))
screen(1)
plot(forecast(Time_Arima,20), main = "Auto ARIMA")
screen(2)
plot(forecast(rime_ets,20), main = "ETS ")
screen(3)
plot(forecast(time_hw,20), main = "HoltWinters")
screen(4)
plot(forecast(time_tslm,h=20), main = "Linear Regression")


#now we have all the models, we need to find the best fitting model now.
#to check that we use the AIC criteria.
#relative probability of finding less information loss is identified using the AIC values
#model with the lowest AIC values has the lowest informaton loss.
#HoltWinters do not use the MAximuum likelyhood function. Hence Error in UseMethod("logLik") : 
#o applicable method for 'logLik' applied to an object of class "HoltWinters"

AIC(time_hw,Time_Arima_m,Time_Arima,time_tslm,rime_ets)
#removing holt winters
AIC(Time_Arima_m,Time_Arima,time_tslm,rime_ets)

#Time_Arima_m has lowest AIC value, hence it is best fitting predictive model.